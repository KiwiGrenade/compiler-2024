#ifndef TYPES_HPP
#define TYPES_HPP

#include "AST.hpp"
#include "CodeBlock.hpp"

#endif